GitLab is for bug reports only.  
Please, head over to our support server at https://invite.nadeko.bot/ and ask your question in the #help channel.