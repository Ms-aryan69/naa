﻿namespace NadekoBot.Modules.Nsfw
{
    public interface INsfwService
    {
        
    }
    
    public class NsfwService
    {
        
    }
}