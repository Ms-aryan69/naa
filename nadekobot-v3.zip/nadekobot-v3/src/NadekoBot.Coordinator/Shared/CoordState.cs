﻿using System.Collections.Generic;

namespace NadekoBot.Coordinator
{
    public class CoordState
    {
        public List<JsonStatusObject> StatusObjects { get; init; }
    }
}