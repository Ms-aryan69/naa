# How to contribute

1. Make Merge Requests to the [**v3 branch**](https://gitlab.com/Kwoth/nadekobot/tree/v3)
2. Keep a single Merge Request to a single feature
3. Fill out the MR template

Thanks for all your help ^\_^