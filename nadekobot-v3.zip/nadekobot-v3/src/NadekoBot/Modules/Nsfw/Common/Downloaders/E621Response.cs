﻿using System.Collections.Generic;

namespace NadekoBot.Modules.Nsfw.Common
{
    public class E621Response
    {
        public List<E621Object> Posts { get; set; }
    }
}