[![Discord](https://discordapp.com/api/guilds/117523346618318850/widget.png)](https://discord.gg/nadekobot)
[![Documentation Status](https://readthedocs.org/projects/nadekobot/badge/?version=latest)](http://nadekobot.readthedocs.io/en/v3/?badge=v3)
[![Discord Bots](https://discordbots.org/api/widget/status/116275390695079945.svg)](https://top.gg/bot/116275390695079945)  

  
[![nadeko0](https://cdn.nadeko.bot/tutorial/docs-top.png)](https://nadeko.bot/)  
  
[![nadeko1](https://cdn.nadeko.bot/tutorial/docs-mid.png)](https://invite.nadeko.bot/)  
 
[![nadeko2](https://cdn.nadeko.bot/tutorial/docs-bot.png)](https://nadeko.bot/commands)

### Useful links
- ❗ [2.x to v3 migration guide](https://nadekobot.readthedocs.io/en/v3/guides/migration-guide/)
- [Self hosting Guides and Docs](https://nadekobot.readthedocs.io/en/v3)
- [Discord support server](https://discord.nadeko.bot)
