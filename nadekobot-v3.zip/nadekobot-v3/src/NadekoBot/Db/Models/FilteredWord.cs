﻿namespace NadekoBot.Services.Database.Models
{
    public class FilteredWord : DbEntity
    {
        public string Word { get; set; }
    }
}
