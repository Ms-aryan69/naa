﻿namespace NadekoBot.VotesApi
{
    public static class ConfKeys
    {
        public const string DISCORDS_KEY = "DiscordsKey";
        public const string TOPGG_KEY = "TopGGKey";
    }
}