using System;

namespace NadekoBot.VotesApi
{
    public class Vote
    {
        public ulong UserId { get; set; }
    }
}