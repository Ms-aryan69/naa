﻿namespace NadekoBot.Common.TypeReaders
{
    public enum AddRemove
    {
        Add = int.MinValue,
        Rem = int.MinValue + 1,
        Rm = int.MinValue + 1,
    }
}
