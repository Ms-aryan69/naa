namespace NadekoBot.Modules.Gambling
{
    public enum GamblingError
    {
        None,
        NotEnough
    }
}