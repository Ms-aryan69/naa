﻿namespace NadekoBot.Modules.Nsfw.Common
{
    public enum Booru
    {
        Safebooru,
        E621,
        Derpibooru,
        Rule34,
        Gelbooru,
        Konachan,
        Yandere,
        Danbooru,
        Sankaku
    }
}
