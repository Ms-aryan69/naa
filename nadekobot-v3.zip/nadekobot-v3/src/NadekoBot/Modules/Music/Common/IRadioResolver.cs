﻿namespace NadekoBot.Modules.Music
{
    public interface IRadioResolver : IPlatformQueryResolver
    {
        
    }
}