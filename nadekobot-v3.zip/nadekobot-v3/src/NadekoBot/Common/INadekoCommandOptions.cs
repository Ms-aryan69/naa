﻿namespace NadekoBot.Common
{
    public interface INadekoCommandOptions
    {
        void NormalizeOptions();
    }
}
