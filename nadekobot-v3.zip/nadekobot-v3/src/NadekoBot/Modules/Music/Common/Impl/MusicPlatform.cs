﻿namespace NadekoBot.Modules.Music
{
    public enum MusicPlatform
    {
        Radio,
        Youtube,
        Local,
        SoundCloud,
    }
}