﻿namespace NadekoBot.Modules.Searches.Common
{
    public class HearthstoneCardData
    {
        public string Text { get; set; }
        public string Flavor { get; set; }
        public bool Collectible { get; set; }

        public string Img { get; set; }
        public string ImgGold { get; set; }
        public string PlayerClass { get; set; }
    }
}
